package #
Date::Manip::TZ::etgmtm05;
# Copyright (c) 2008-2026 Sullivan Beck.  All rights reserved.
# This program is free software; you can redistribute it and/or modify it
# under the same terms as Perl itself.

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'tzdata' is run.
#    Generated on: Tue Sep  1 12:20:25 EDT 2026
#    Data version: tzdata2026c
#    Code version: tzcode2026c

# This module contains data from the zoneinfo time zone database.  The original
# data was obtained from the URL:
#    ftp://ftp.iana.org/tz

use strict;
use warnings;
require 5.010000;

our (%Dates,%LastRule);
END {
   undef %Dates;
   undef %LastRule;
}

our ($VERSION);
$VERSION='7.00';
END { undef $VERSION; }

%Dates         = (
   1    =>
     [
        [ [1,1,2,0,0,0],[1,1,1,10,0,0],'-14:00:00',[-14,0,0],
          'GMT-14',0,[9999,12,31,0,0,0],[9999,12,30,10,0,0],
          '0001010200:00:00','0001010110:00:00','9999123100:00:00','9999123010:00:00' ],
     ],
);

%LastRule      = (
);

1;
